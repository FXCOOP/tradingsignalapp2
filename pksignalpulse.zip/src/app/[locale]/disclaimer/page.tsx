export default function Page(){
  return (
    <div className="prose max-w-none card p-6">
      <h1>Disclaimer</h1>
      <p>PK Signal Pulse provides educational trading signals for Pakistani traders. Not financial advice.</p>
    </div>
  );
}