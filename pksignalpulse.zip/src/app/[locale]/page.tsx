import { getLatestSignals } from '@/lib/signals';
import Link from 'next/link';
import { getTranslations } from 'next-intl/server';
import LockBlur from '@/components/LockBlur';
import AffiliateRibbon from '@/components/AffiliateRibbon';

export default async function Home({ params: { locale } }:{ params: { locale:'en'|'ur' }}){
  const t = await getTranslations('home');
  const signals = await getLatestSignals(4);
  return (
    <div className="space-y-6">
      <AffiliateRibbon />
      <section className="text-center space-y-3">
        <h1 className="text-3xl font-extrabold">{t('title')}</h1>
        <p className="text-gray-600">{t('subtitle')}</p>
        <div className="flex gap-3 justify-center">
          <Link href={`/${locale}/signals`} className="btn-primary">⚡ {t('viewSignals')}</Link>
          <Link href={`/${locale}/subscribe`} className="btn-ghost">📩 {t('subscribe')}</Link>
        </div>
      </section>
      <section className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {signals.map(s => (
          <article key={s.id} className="card p-5 space-y-2">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold">{s.instrument} — {s.direction}</h3>
              <span className="badge">{new Date(s.date).toLocaleString()}</span>
            </div>
            <p className="text-xs text-gray-500">{s.sentiment}</p>
            <LockBlur>
              <div className="grid grid-cols-3 gap-3 text-sm mt-2">
                <div><strong>Entry</strong><br/>{s.entry}</div>
                <div><strong>SL</strong><br/>{s.stopLoss}</div>
                <div><strong>TP</strong><br/>{JSON.parse(s.takeProfits).join(', ')}</div>
              </div>
            </LockBlur>
            <div className="flex gap-3 pt-2">
              <Link className="btn-ghost" href={`/${locale}/signals`}>Open</Link>
              <Link className="btn-primary" href={`/${locale}/subscribe`}>Subscribe</Link>
            </div>
          </article>
        ))}
      </section>
    </div>
  );
}