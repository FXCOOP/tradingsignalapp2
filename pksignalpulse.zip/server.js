import { createServer } from 'http';
import next from 'next';
import cron from 'node-cron';
import { runDailyJob } from './scripts/daily.js';

const dev = process.env.NODE_ENV !== 'production';
const app = next({ dev });
const handle = app.getRequestHandler();

app.prepare().then(() => {
  cron.schedule('0 8 * * *', async () => {
    try { await runDailyJob(); } catch (e) { console.error('Daily job error', e); }
  });

  createServer((req, res) => handle(req, res)).listen(process.env.PORT || 3000, (err) => {
    if (err) throw err;
    console.log('> Ready on http://localhost:' + (process.env.PORT || 3000));
  });
});