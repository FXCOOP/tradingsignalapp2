import { prisma } from '@/lib/db';

async function main(){
  if (await prisma.signal.count() > 0) return;
  await prisma.subscriber.create({ data: { email: 'demo@local.test' } });
  console.log('Seeded demo subscriber');
}
main().then(()=>process.exit(0));